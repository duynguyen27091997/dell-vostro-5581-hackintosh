# Dell Vostro 5581

This build running on MacOs X

# System specification

    1.Name:           Dell Vostro 5581
    2.CPU:            Intel Core i7-8565U
    3.Graphic:        Intel UHD620
    4.Wifi:           REPLACED WITH DW1560 (AirDrop and Handoff Working perfectly)

# Step to install

    1. Run and Install Clover_v2.5k_r5058.pkg with EFI 
    2. Replace Clover folder in EFI partition
    3. Trackpad: Move CodecCommander.kext in Trackpad/LE and KextBeast to Desktop, run KextBeast select L/E
    4: Enable HiDPi https://github.com/xzhih/one-key-hidpi
    5. Enjoy
